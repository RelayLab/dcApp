﻿Imports System.Net
Imports System.Net.Sockets
Module ClientNetworkService

    Private client As TcpClient
    ''' <summary>
    ''' Асинхронно подключается к TcpListener на указанном компьютере
    ''' </summary>
    ''' <param name="ThisPcInfo">Информация о ресурсах клиента</param>
    ''' <param name="ServerName">Имя сервера</param>
    ''' <param name="LoopFunc">Указатель на функцию, которую после подключения будет выполнять клиент в бесконечном цикле</param>
    ''' <remarks></remarks>
    Public Sub StartClient(ThisPcInfo As ClientInfo, _
                                 ServerName As String, _
                                 LoopFunc As Func( _
                                                 Of List(Of IElementaryJob),  _
                                                 ClientInfo,  _
                                                 List(Of IJobResult)))
        client = New TcpClient
        Try
            Dim ServerIp As IPAddress = _
                System.Net.Dns.GetHostEntry(ServerName).AddressList.First( _
                    Function(x As IPAddress)
                            Return Not x.IsIPv6LinkLocal AndAlso Not x.IsIPv6Multicast AndAlso Not x.IsIPv6SiteLocal
                        End Function) 'Спрашивает ip4 адрес сервера с указанным именем у ДНС-сервера

            Do  'бесконечный цикл, в котором через 1сек производится попытка подключения к серверу
                If TryConnect(ServerIp, 55001) Then
                    StartClientLoop(client, ThisPcInfo, LoopFunc) 'бесконечный цикл, в котором запрашивается, выполняется и отправляется работа
                Else
                    Threading.Thread.Sleep(1000)
                End If
            Loop

        Catch OdEx As ObjectDisposedException
            MsgBox("Соединение с сервером прервано. " & OdEx.Message)
            'кто-то отключился
        Catch SocEx As SocketException
            MsgBox("Указанный сервер не найден")
        End Try
    End Sub
    Private Function TryConnect(ServerIp As IPAddress, Port As Integer) As Boolean
        Try
            If client.Connected = False Then _
                client.Connect(ServerIp, 55001) 'асинхронно подключается к указанному порту
            Return True
        Catch SocEx As SocketException
            Return False
        End Try
    End Function

    ''' <summary>
    ''' бесконечный цикл, в котором клиент запрашивает, выполняет и отправляет работу
    ''' </summary>
    ''' <param name="client"></param>
    ''' <param name="ThisPcInfo">Информация о ресурсах клиента</param>
    ''' <param name="LoopFunc">указатель на функцию, в которой выполняется полученная работа.
    ''' Нужна для того, чтобы в реализации клиента оставить только сетевую часть, а саму работу вынести в другую dll</param>
    ''' <remarks></remarks>
    Private Async Sub StartClientLoop(client As TcpClient, _
                                      ThisPcInfo As ClientInfo, _
                                      LoopFunc As Func( _
                                                      Of List(Of IElementaryJob),  _
                                                      ClientInfo,  _
                                                      List(Of IJobResult)))
        Try
            Dim message As New TcpMessage With {.Results = New List(Of IJobResult)} 'первый раз на сервер отправляется пустое сообщение с инф. о ресурсах клиента
            While client.Connected
                message.ClientInfo = ThisPcInfo
                SendMessageAsync(client, message)                             'отправить сообщение с результатами и инф. о ресурсах
                'Await SendMessageAsync(client, message)                             'отправить сообщение с результатами и инф. о ресурсах
                message = ReadMessageAsync(client).Result                            'получить работы
                'message = Await ReadMessageAsync(client)                            'получить работы
                If message.Jobs.Count = 0 Then client.Close() 'если прислано пустое сообщение, т.е. работ нет, то отключиться от сервера

                JobsSingleton.Instance.Jobs = message.Jobs  'для обновления работ в пользовательском интерфейсе
                JobsSingleton.Instance.UpdateJobs()

                message.Results = LoopFunc.Invoke(message.Jobs, ThisPcInfo) 'выполнить работы в отдельной функции
            End While
        Catch IoEx As System.IO.IOException
            MsgBox("Соединение с сервером потеряно")
        End Try
    End Sub

    Public Sub StopClient()
        If client IsNot Nothing Then
            client.Close()
            client = Nothing
        End If
        JobsSingleton.Instance.UpdateStatus("Работа закончена")
    End Sub

End Module
