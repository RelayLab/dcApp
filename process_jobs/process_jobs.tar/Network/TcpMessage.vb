﻿Imports System.Runtime.Serialization.Formatters.Binary
Imports System.IO
''' <summary>
''' Сообщение, пересылаемое между сервером и клиентом
''' </summary>
''' <remarks>В нем посылаются работы, результаты и доп.инфо.</remarks>
<Serializable>
Public Class TcpMessage
    Public Property Results As List(Of IJobResult)
    Public Property ClientInfo As ClientInfo      'инф. о клиенте
    Public Property Jobs As List(Of IElementaryJob)  'список элементарных работ

    Public Shared Function IsMessageComplete(data As List(Of Byte)) As Boolean
        Dim l As Long = BitConverter.ToInt64(data.ToArray, 0)   'первыми байтами пересылаемого сообщения data() является длина сообщения (число типа лонг)
        Return (l = data.LongCount - Len(l))                    'если это число = уже прочитанные данные, то сообщение передано полностью
    End Function
    ''' <summary>
    ''' Восстановить сообщение типа TcpMessage из байтов
    ''' </summary>
    ''' <param name="data">байты сообщения, представляющие экземпляр класса TcpMessage</param>
    ''' <returns>Возвращает готовое сообщение TcpMessage</returns>
    ''' <remarks>Т.е. провести десериализацию</remarks>
    Public Shared Function FromByteArray(data() As Byte) As TcpMessage
        Dim MS As New MemoryStream
        Dim BF As New BinaryFormatter
        MS.Write(data, Len(MS.Length), data.Length - Len(MS.Length))            'бинарные данные, за исключением первых байтов, отведенных под размер сообщения, записываются в поток
        MS.Seek(0, SeekOrigin.Begin)                                            'в потоке установим каретку в начало
        Dim Message As TcpMessage = CType(BF.Deserialize(MS), TcpMessage) 'десериализация в сообщение
        Return Message
    End Function

    'serialize content into a byte array according to the message protocol specification
    ''' <summary>
    ''' Сериализовать сообщение в набор байтов
    ''' </summary>
    ''' <param name="Message">Сериализуемое сообщение</param>
    ''' <returns>Возвращает массив байтов = длина сообщения и само сообщение</returns>
    ''' <remarks></remarks>
    Public Shared Function ToByteArray(Message As TcpMessage) As List(Of Byte)
        Dim MS As New MemoryStream
        Dim BF As New BinaryFormatter
        BF.Serialize(MS, Message)                           'сериализует сообщение в набор байтов
        Dim result As New List(Of Byte)                     'новый контейнейр, в который сейчас положим две части сообщения
        result.AddRange(BitConverter.GetBytes(MS.Length))   'заголовком (первыми байтами) сообщения будут длина этого сообщения, записанные с помощью типа данных лонг
        result.AddRange(MS.ToArray())                       'собственно прикрепляем само сообщение
        Return result
    End Function
End Class
