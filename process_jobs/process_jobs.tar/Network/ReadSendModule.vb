﻿Imports System.Net
Imports System.Net.Sockets

Public Module ReadSendModule
    ''' <summary>
    ''' Асинхронно читает сообщение из потока
    ''' </summary>
    ''' <param name="client">Клиент, сетевой поток которого будет читаться</param>
    ''' <returns>Возвращает прочитанное сообщение</returns>
    ''' <remarks>Использует буфер для чтения</remarks>
    Public Async Function ReadMessageAsync(client As TcpClient) As Task(Of TcpMessage)
        Dim received As New List(Of Byte)                   'для будущего сообщения
        Dim buffer(client.ReceiveBufferSize - 1) As Byte    'буфер, который читает сетевой поток
        Dim read As Integer                                 'кол-во прочитанных байт из сетевого потока

        Try
            Do
                read = Await client.GetStream.ReadAsync(buffer, 0, buffer.Length)   'читает поток в буфер и возвращает число прочитанных байт
                received.AddRange(buffer.Take(read))                                'в будущее сообщение записывает содержимое буфера
            Loop Until TcpMessage.IsMessageComplete(received)                    ' если кол-во прочитанных байт = заголовку сообщения, то сообщение закончено. Иначе продолжить читать в буфер

            Dim message As TcpMessage = TcpMessage.FromByteArray(received.ToArray)    'десериализация
            Return message
        Catch IoEx As IO.IOException    'если соединение было разорвано, то вернуть пустое сообщение
            MsgBox(IoEx.Message)
            Return New TcpMessage With {.ClientInfo = New ClientInfo(0, "")}
        Catch ex As Exception       'в дургом случае просто вывести меседжбокс и бросить исключение
            MsgBox(ex.Message)
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' Асинхронно пишет сообщение в поток
    ''' </summary>
    ''' <param name="client">Клиент, в сетевой поток которого будет писаться сообщение</param>
    ''' <param name="message">Сообщение, которое будет писаться</param>
    ''' <returns>Возвращает Task для асинхронного ожидания</returns>
    ''' <remarks></remarks>
    Public Async Function SendMessageAsync(client As TcpClient, message As TcpMessage) As Task
        Try
            Dim stream As NetworkStream = client.GetStream 'сетевой поток, в который будет вестись запись
            Dim buffer As List(Of Byte) = TcpMessage.ToByteArray(message) 'отправляемое сообщение, сериализованное в байты
            Await stream.WriteAsync(buffer.ToArray, 0, buffer.Count) 'асинхронно записать в поток набор байтов
        Catch InvOp As InvalidOperationException 'ловит ошибку, если соединение было разорвано
            MsgBox(InvOp.Message)
        End Try
    End Function
End Module
