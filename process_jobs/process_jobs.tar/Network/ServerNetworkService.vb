﻿Imports System.Net
Imports System.Net.Sockets
Module ServerNetworkService

    Private listener As TcpListener
    Private clients As New List(Of TcpClient)
    ''' <summary>
    ''' Асинхронно ждет подключений TcpClient
    ''' </summary>
    ''' <param name="LoopFunc">Указатель на функцию, которая будет исполняться после подключения каждого клиента</param>
    ''' <remarks></remarks>
    Public Async Sub StartServer( _
                                LoopFunc As Func(Of List(Of IJobResult),  _
                                                 ClientInfo,  _
                                               List(Of IElementaryJob)))
        Try
            listener = New TcpListener(IPAddress.Any, 55001)
            listener.Start()
            Do
                Dim client As TcpClient = Await listener.AcceptTcpClientAsync   'ждать новых клиентов
                clients.Add(client)
                StartServerLoop(client, LoopFunc) 'бесконечный цикл, в котором сервер получает результаты, сохраняет/обрабатывает их и раздает новые работы ТОЛЬКО ОДНОМУ КЛИЕНТУ
                'для каждого клиента начинатеся отдельный такой цикл
            Loop
        Catch OdEx As ObjectDisposedException
            MsgBox(OdEx.Message)
            'кто-то отключился
        End Try

    End Sub
    ''' <summary>
    ''' Бесконечный цикл, в котором сервер получает результаты, сохраняет/обрабатывает их и раздает новые работы
    ''' </summary>
    ''' <param name="client">Клиент, с которым происходит общение </param>
    ''' <param name="LoopFunc">указатель на функцию, в которой обрабатываются результаты и работа.
    ''' Нужна для того, чтобы в реализации сервера оставить только сетевую часть, а саму работу вынести в другую dll</param>
    ''' <remarks></remarks>
    Async Sub StartServerLoop(client As TcpClient, _
                              LoopFunc As Func(Of List(Of IJobResult),  _
                                               ClientInfo,  _
                                               List(Of IElementaryJob)))
        Do
            If client.Connected Then
                Dim ClientResultsMsg As TcpMessage = Await ReadMessageAsync(client) 'получить сообщение от клиента (первое сообщение = только о ресурсах клиента)
                Dim JobsToSend As List(Of IElementaryJob) = _
                    LoopFunc.Invoke( _
                        ClientResultsMsg.Results, _
                        ClientResultsMsg.ClientInfo) 'внешняя функция по обработке результатов - сохранить, пометить как сделанные, сформировать новые работы

                'If SaveEnabled Then SaveResults(ResultsMsg.Results)
                Await SendMessageAsync(client, New TcpMessage With {.Jobs = JobsToSend}) 'Послать новое сообщение с работами
                If JobsToSend.Count = 0 Then client.Close() 'если есть свободные работы, то послать их клиенту

            Else
                clients.Remove(client) 'если подключения нет, то убрать данного клиента
                Exit Do
            End If
        Loop
    End Sub

    Public Sub StopServer()
        If listener IsNot Nothing Then
            listener.Stop()
            listener = Nothing
            JobsSingleton.Instance.UpdateStatus("Работа закончена")
        End If

    End Sub

End Module
