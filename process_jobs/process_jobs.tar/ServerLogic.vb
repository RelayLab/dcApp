﻿Imports dcUser


Friend Module ServerLogic
    ''' <summary>
    ''' функция, принимающая работы, отмечающая их как сделанные и выдающая новые по числу тредов у клиента
    ''' </summary>
    ''' <param name="Jobs">список все работ</param>
    ''' <param name="Results">входные результаты, которые будут отмечены как сделанные</param>
    ''' <param name="ClientInfoInst">инфа о клиенте</param>
    ''' <returns>возвращает новые работы на основе инфы о клиенте</returns>
    ''' <remarks></remarks>
    Friend Function ServerLoop(
                              Jobs As List(Of IElementaryJob), _
                              Results As List(Of IJobResult), _
                              ClientInfoInst As ClientInfo) _
                          As List(Of IElementaryJob)

        MarkAsCompleted(Jobs, Results) 'пометить как сделанные

        'на основе инфы о клиенте взять новые несделанные работы
        Dim OutputJobs As List(Of IElementaryJob) = (From job In Jobs
                                                    Where job.IsDone = False
                                                    Take ClientInfoInst.MaxThreadsCount).ToList
        OutputJobs.ForEach(Sub(x)
                               x.IsProcessing = True
                               x.ClientName = ClientInfoInst.ClientName
                           End Sub) 'пометить эти работы как находящиеся в обработке у клиента

        Return OutputJobs
    End Function

    ''' <summary>
    ''' пометить работы как сделанные
    ''' </summary   >
    ''' <param name="Results">сделанные работы</param>
    ''' <remarks></remarks>
    Friend Sub MarkAsCompleted(AllJobs As List(Of IElementaryJob), Results As List(Of IJobResult))
        If Results IsNot Nothing Then
            For Each ResultsTable As IJobResult In Results
                AllJobs.Find(Function(x)
                                 Return x.Id = ResultsTable.JobId
                             End Function).IsDone = True    'пометить работы как сделанные
            Next
        End If
    End Sub
End Module
