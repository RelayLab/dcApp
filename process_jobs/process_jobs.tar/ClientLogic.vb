﻿
Imports dcUser

Module ClientLogic
    ''' <summary>
    ''' функция, в которой отдельные работы раскидываются по тредам и выполняются
    ''' </summary>
    ''' <param name="Jobs">лист элементарных работ</param>
    ''' <param name="ThisPcInfo">информация о компьютере клиента</param>
    ''' <returns>возвращает результаты выполнения элементарных работ</returns>
    ''' <remarks></remarks>
    Friend Function ClientLoop( _
                              Jobs As List(Of IElementaryJob), _
                              ThisPcInfo As ClientInfo) _
                          As List(Of IJobResult)


        Dim OutputResults As New List(Of IJobResult)
        Dim Threads As New List(Of System.Threading.Thread)

        'для каждой работы завести отдельный тред
        For Each Job As IElementaryJob In Jobs
            'объект результата работы сразу добавить в выходной список, и затем по ссылке передать его в функцию вычисления
            'тогда не надо будет возвращать его из Thread, что сделать по-простому никак нельзя.
            Dim Result As New JobResult
            OutputResults.Add(Result)
            Dim SeparateJobThread As New System.Threading.Thread(Sub()
                                                                     ExecuteSingleJob( _
                                                                         Job, _
                                                                         Result, _
                                                                         True, _
                                                                         True)
                                                                 End Sub)
            SeparateJobThread.Name = "Job: " & Job.Id 'назвать для дебаггинга
            SeparateJobThread.SetApartmentState(Threading.ApartmentState.STA)
            Threads.Add(SeparateJobThread) 'добавить в общий список тредов, чтобы можно потом было отследить их завершение
            SeparateJobThread.Start()
        Next

        'после того, как все треды запущены, подождать завершения всех тредов
        For Each thread In Threads
            thread.Join()
        Next

        Return OutputResults
    End Function
End Module
